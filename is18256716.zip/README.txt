*********** README ************

Marcin Sek 		18254187
Jordan Marshall 	18256716
Ademide Adenuga		18220258
Rioghan Lowry		18226531

*******************************
*HOW TO RUN*

Extract the "is18256716.zip"
To run, first open CMD or Powershell.
Type "javac is18256716.java" to compile the program.
Type "java is18256716" to run the program.

*NOTE*

This program contains JavaFX.

*******************************

First click on any square in the grid to initialise a start point. Then, click any other square in the grid to intialise an end point. The algorithm should run and draw a blue path from the start point to the end point. If the algorithm doesnt find a valid path, then it will not show any blue path. After the path has been drawn, press the windows again to reset the grid and start again.

*******************************

Start = Green
End = Red
Path = Blue
Obstacle = Black
Open Square = Grey

*******************************